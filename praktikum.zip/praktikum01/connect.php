<?php
$server = "localhost";
$user = "root";
$password = "";
$a = "praktikum_pwd";

$db = mysqli_connect($server, $user, $password, $a);

if (!$db) {
    die("Gagal terhubung dengan database: " . mysqli_connect_error());
}
