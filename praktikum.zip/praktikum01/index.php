<?php
session_start();
if (!isset($_SESSION["username"])) {
    echo "Anda harus login dulu <br><a href='login.php'>Klik disini</a>";
    exit;
} else {
    echo "Selamat Datang " . $_SESSION['username'];
    echo "<a href='logout.php'> Logout</a>";
} ?>
<!DOCTYPE html>
<html>

<head>
    <title>Tampilkan Data Identitas</title>
</head>

<body>
    <br><br>
    <a href="tambah.php" class="button-tambah">+ TAMBAH IDENTITAS</a>
    <br><br>
    <table border="1">
        <tr>
            <th>NO</th>
            <th>Nomor Identitas</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Nomor HP</th>
            <th>Jenis Kelamin</th>
            <th>Kodepos</th>
            <th>Aksi</th>
        </tr>
        <?php
        include 'connect.php';
        $no = 1;
        $data = mysqli_query($db, "SELECT * FROM identitas");
        while ($d = mysqli_fetch_array($data)) {
        ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $d['no_identitas']; ?></td>
                <td><?php echo $d['nama']; ?></td>
                <td><?php echo $d['alamat']; ?></td>
                <td><?php echo $d['no_telp']; ?></td>
                <td><?php echo $d['jk']; ?></td>
                <td><?php echo $d['kodepos']; ?></td>
                <td>
                    <a href="edit.php?id=<?php echo $d['no_identitas']; ?>" class="button">EDIT</a>
                    <a href="hapus.php?id=<?php echo $d['no_identitas']; ?>" class="button-delete">HAPUS</a>
                </td>
            </tr>
        <?php
        }
        ?>
    </table>
</body>

</html>