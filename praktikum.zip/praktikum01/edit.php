<?php
include "connect.php";
$id = $_GET['id']; // ada pada link edit dalam index.php 
$data = mysqli_query($db, "SELECT * FROM identitas WHERE no_identitas='$id'");
while ($d = mysqli_fetch_array($data)) {
?>
    <!DOCTYPE html>
    <html>

    <head>
        <title>Belajar PHP | Edit Data</title>
        <style>
            input[type=text],
            select,
            textarea {
                width: 100%;
                padding: 12px 20px;
                margin: 8px 0;
                display: inline-block;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
            }

            input[type=submit] {
                width: 100%;
                background-color: #4CAF50;
                color: white;
                padding: 14px 20px;
                margin: 8px 0;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }

            input[type=submit]:hover {
                background-color: #45a049;
            }

            p {
                border-radius: 5px;
                background-color: #f2f2f2;
                padding: 20px;
            }
        </style>
    </head>

    <body>
        <header>
            <h3>Edit Identitas</h3>
        </header>
        <form action="proses-edit.php" method="POST">
            <!-- <fieldset> -->
            <input type="hidden" name="no_identitas" value="<?php echo $d['no_identitas']; ?>" />
            <p>
                <label for="nama">Nama: </label>
                <input type="text" name="nama" value="<?php echo $d['nama']; ?>" />
            </p>
            <p>

                <label for="alamat">Alamat: </label>
                <textarea name="alamat"><?php echo $d['alamat'] ?></textarea>
            </p>
            <p>
                <label for="no_telp">Nomor HP: </label>
                <input type="text" name="no_telp" value="<?php echo $d['no_telp']; ?>" />
            </p>
            <p>
                <label for="jk">Jenis Kelamin: </label>
                <?php $jk = $d['jk']; ?>
                <label><input type="radio" name="jk" value="laki-laki" <?php echo ($jk == 'laki-laki') ? "checked" : "" ?>> Laki-laki</label>
                <label><input type="radio" name="jk" value="perempuan" <?php echo ($jk == 'perempuan') ? "checked" : "" ?>> Perempuan</label>
            </p>
            <p>
                <label for="kodepos">Kodepos: </label>
                <input type="text" name="kodepos" placeholder="kodepos" value="<?php echo $d['kodepos'] ?>" />
            </p>
            <p>
                <input type="submit" value="Simpan" name="simpan" />
            </p>
            </fieldset>
        </form>
    </body>
<?php } ?>

    </html>